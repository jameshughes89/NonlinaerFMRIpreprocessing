# Batch copy stuff from HCP directory structure into a local directory and transform it into
# 4mm MNI space (compatible with the rest of our prototype pipeline)

# This is the good script -- use this one unless you have a good reason not to!

# 2 Septemper 2015

# Where is the unzipped HCP data stored?
datadir=./downloaded

# Working directory for output
workdir=.


# Use this one!
subjlist="100307 100408 101006 101107 101309 101410 101915 102008 102311 102816 103111 103414 103515 103818 104012 104820 105014 105115 105216 105923 106016 106319 106521 107321 107422 108121 108323 108525 108828 109123 109325 110411 111312 111413 111514 111716 113215 113619 113922 114419 114924 115320 116524 117122 117324 118528 118730 118932 119833 120111 120212 120515 121618 122317 122620 123117 123420 123925 124220 124422 124826 125525 126325 126628 127630 127933 128127 128632 129028 130013 130316 130922 131217 131722 131924 133019 133625 133827 133928 134324 135225 135528 135932 136227 136833 137027 137128 137633 137936 138231 138534 139233 139637 140117 140824 140925 141422 141826 142828 143325 144832 145834"

tasklist="RELATIONAL SOCIAL WM"

for task in $tasklist
do
	for subj in $subjlist 
	do
    echo
	echo Unzipping data for HCP subject $subj, task $task
	unzip $datadir/${subj}_3T_tfMRI_${task}_preproc -d $datadir
    echo Copying timeseries for HCP subject $subj, task $task
    cp $datadir/$subj/MNINonLinear/Results/tfMRI_${task}_RL/tfMRI_${task}_RL.nii.gz $workdir/

    echo
    echo 'Transforming timeseries to 4mm MNI'
    fsl5.0-flirt -in tfMRI_${task}_RL.nii.gz -ref tfMRI_${task}_RL.nii.gz -out tfMRI_${task}_RL_${subj}_4mm.nii.gz -applyisoxfm 4

    echo
    echo 'Cleaning up'
    rm tfMRI_${task}_RL.nii.gz
    rm -r $datadir/${subj}
  
  done

done
